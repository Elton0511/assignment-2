package com.example.assignment2

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val backbutton = findViewById<Button>(R.id.backbutton)
        val imageView3 = findViewById<ImageView>(R.id.imageView3)
        val progressBar2 = findViewById<ProgressBar>(R.id.progressBar2)
        val progressBar3 = findViewById<ProgressBar>(R.id.progressBar3)
        val progressBar4 = findViewById<ProgressBar>(R.id.progressBar4)

        // when button1 is clicked image about tiger eating  is shown
        button1.setOnClickListener {
            imageView3.setImageResource(R.drawable.tigereating)
        }

        // when button2 is clicked image about tiger bathing is shown
        button2.setOnClickListener {
            imageView3.setImageResource(R.drawable.tigerbathing)
        }

        // when button 3 is clicked image about tiger playing is shown
        button3.setOnClickListener {
            imageView3.setImageResource(R.drawable.tigerplaying)
        }

        // when this button is clicked return to main page
        backbutton.setOnClickListener {


            fun startProgress(progressBar: ProgressBar) {
                Thread {
                    for (i in 0..100) {
                        progressBar2.progress = i
                        progressBar3.progress = i
                        progressBar4.progress = i
                        Thread.sleep(50) // pause for 50 milliseconds

                        button1.setOnClickListener {
                            startProgress(progressBar2)
                        }

                        button2.setOnClickListener {
                            startProgress(progressBar3)
                        }

                        button3.setOnClickListener {
                            startProgress(progressBar4)
                                }
            }

                }




            }

        }
            }
            }












